# GRAVITYFOUR — 99 characters

- `characters/`: 99 transparent 16 × 16 PNG sprites, named with pronounceable four-letter names.
- `contact-sheet.png`: all 99 sprites on one sheet.
- `gallery.html`: enlarged, clickable visual index. Hover over a face for its layer choices and colors.
- `characters.json`: name, selected PSD layers, palette colors, and image digest for each character.
- `generate.py` and `psd_reader.py`: reproducible generator. Run `python generate.py <path-to-human01.psd>`.

The source is `GRAVITYFOUR/data/human01.psd`. Its 11 hair, 10 mouth, and 15 eye layers are all distinct image data. Eye color variants count as different eye choices. Every pair among the 99 characters differs in at least two of those three layer choices. Hair, clothing, and skin colors are chosen from their respective `* color` layers with a fixed random seed.
